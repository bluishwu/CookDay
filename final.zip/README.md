# CookDay

一款食谱记录程序，轻松记录食材、步骤和笔记，易于分享与管理。
记录您的每日烹饪，将其化为可回顾与共享的经验宝藏！

## ✨ 功能特色

* 📖 菜谱创建与管理
* 📋 食材清单管理
* 📝 制作步骤记录
* 📒 改进笔记记录
* 📷 成品图片上传
* ⚙️ 管理模式登入
* 🔗 URL链接解析
* 🔎 常用食材快速选择
* 🔀 便捷拖动排序（常用食材、步骤、笔记、图片）

## 🚀 部署说明
### 安装步骤

1. 克隆仓库
```bash
git clone https://github.com/bluishwu/CookDay
cd CookDay-main
```

3. 安装依赖
```bash
pip install -r requirements.txt
```
即
```
Flask==3.0.0
Flask-SQLAlchemy==3.1.1
Flask-Login==0.6.3
Pillow==10.2.0
python-dotenv==1.0.0
Werkzeug==3.0.1
requests==2.31.0
beautifulsoup4==4.12.2 
```
5. 运行应用
```bash
python run.py
```

6. 首次访问
- 访问 http://localhost:5000
-默认密码为admin

### 配置说明

在 `config.py` 中可以修改以下配置：
- `SECRET_KEY`：应用密钥（请修改为随机字符串）
- `UPLOAD_FOLDER`：图片上传目录
- `MAX_CONTENT_LENGTH`：最大上传文件大小（默认16MB）

### 目录结构
```
├── app/                    # 应用主目录
│   ├── static/            # 静态文件
│   ├── templates/         # 页面模板
│   ├── models.py         # 数据模型
│   └── routes.py         # 路由和视图
├── migrations/           # 数据库迁移文件
├── config.py            # 配置文件
├── requirements.txt     # 依赖包列表
└── run.py              # 启动脚本
```

## 📝 使用说明

### 基本操作
1. 创建菜谱
   - 点击"新建菜谱"按钮
   - 填写菜名和描述
   - 添加食材和用量
   - 添加制作步骤
   - 添加成品图片
   - 保存菜谱

2. 管理常用食材
   - 在管理面板中添加常用食材
   - 创建菜谱时可快速选择

3. 视频链接支持
   - 在笔记中粘贴抖音/B站视频链接
   - 自动解析视频信息并显示预览

### 注意事项
- 图片上传大小限制为16MB
- 支持的图片格式：jpg、png、gif
- 请定期备份数据库文件

## 🤝 贡献指南

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交改动 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 提交 Pull Request

## 📄 开源协议

本项目采用 MIT 协议开源 - 详见 [LICENSE](LICENSE) 文件 